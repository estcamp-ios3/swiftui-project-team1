//
//  ProblemHistoryView.swift
//  PullItUp
//
//  Created by suji chae on 7/8/25.
//

import SwiftUI
import SwiftData // SwiftData를 사용하겠다고 알려줘요.

struct ProblemHistoryView: View {
    // @Environment(\.modelContext) : 서랍장에서 기록을 추가하거나 수정할 때 사용하는 '손' 같은 거예요.
    @Environment(\.modelContext) private var modelContext

    // @Query : 서랍장에서 기록들을 꺼내오는 주문이에요.
    // sort: 날짜 최신순으로 정렬해주세요!
    @Query(sort: \ProblemSession.date, order: .reverse) private var sessions: [ProblemSession]

    var body: some View {
        NavigationView { // 화면 위에 제목 같은 걸 달 수 있게 해줘요.
            List { // 목록 형태로 보여줄 때 사용하는 아주 편리한 도구예요.
                // groupedSessions.keys.sorted(by: >) : 날짜들을 최신 날짜부터 정렬해요.
                ForEach(groupedSessions.keys.sorted(by: >), id: \.self) { date in
                    // Section : 날짜별로 구분선을 넣어 그룹을 만들어요. (예: 2025. 06. 21)
                    Section(header: Text(formattedDate(date))) { // 섹션의 제목은 날짜로!
                        // groupedSessions[date]! : 해당 날짜의 모든 기록들을 가져와요.
                        // sorted(by: { $0.sessionNumber < $1.sessionNumber }) : 그날의 기록은 1회차, 2회차 순으로 정렬해요.
                        ForEach(groupedSessions[date]!.sorted(by: { $0.sessionNumber < $1.sessionNumber })) { session in
                            HStack { // 한 줄에 여러 내용을 가로로 나란히 놓을 때 사용해요.
                                Text("\(session.sessionNumber)회차") // 1회차, 2회차
                                Spacer() // 빈 공간을 만들어 오른쪽으로 밀어요.
                                Text("\(session.scoreNumerator)/\(session.scoreDenominator)") // 점수 (예: 05/10)
                                Text(session.isCompleted ? "완료" : "미완료") // 완료/미완료 글자
                                    .padding(.horizontal, 8) // 글자 주변에 여백을 줘요.
                                    .padding(.vertical, 4)
                                    .background(session.isCompleted ? Color.blue : Color.gray.opacity(0.2)) // 완료면 파란색 배경, 아니면 회색 배경
                                    .foregroundColor(session.isCompleted ? .white : .black) // 완료면 글자 흰색, 아니면 검은색
                                    .cornerRadius(5) // 모서리를 둥글게 만들어요.
                            }
                        }
                    }
                }
            }
            .navigationTitle("문제풀이이력") // 화면 맨 위에 제목을 달아요.
            .onAppear { // 화면이 나타날 때 한번 실행되는 코드예요.
                // 만약 서랍장에 기록이 하나도 없으면, 샘플 데이터를 넣어줄 거예요.
                if sessions.isEmpty {
                    addSampleData()
                }
            }
        }
    }

    // groupedSessions : 모든 기록(sessions)들을 날짜별로 묶어주는 똑똑한 계산 부분이에요.
    private var groupedSessions: [Date: [ProblemSession]] {
        Dictionary(grouping: sessions) { session in
            Calendar.current.startOfDay(for: session.date) // 정확한 시간 상관없이 '날짜'만 같으면 같은 그룹으로 묶어요.
        }
    }

    // formattedDate : 날짜를 '2025. 06. 21' 이런 형식으로 예쁘게 바꿔주는 기능이에요.
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy. MM. dd" // 날짜 형식을 지정해요.
        return formatter.string(from: date)
    }

    // addSampleData : 앱을 처음 켰을 때 보여줄 가짜 기록들을 넣어주는 부분이에요.
    private func addSampleData() {
        let calendar = Calendar.current

        // 2025.06.21 날짜의 기록들
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 21))!, sessionNumber: 1, scoreNumerator: 5, scoreDenominator: 10, isCompleted: false)) // 1회차, 5/10, 미완료
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 21))!, sessionNumber: 2, scoreNumerator: 10, scoreDenominator: 10, isCompleted: true)) // 2회차, 10/10, 완료

        // 2025.06.22 날짜의 기록들
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 22))!, sessionNumber: 1, scoreNumerator: 20, scoreDenominator: 20, isCompleted: true)) // 1회차, 20/20, 완료

        
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 23))!, sessionNumber: 1, scoreNumerator: 5, scoreDenominator: 10, isCompleted: false))
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 23))!, sessionNumber: 2, scoreNumerator: 20, scoreDenominator: 20, isCompleted: true))
        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 23))!, sessionNumber: 3, scoreNumerator: 10, scoreDenominator: 10, isCompleted: true))

        modelContext.insert(ProblemSession(date: calendar.date(from: DateComponents(year: 2025, month: 6, day: 24))!, sessionNumber: 1, scoreNumerator: 20, scoreDenominator: 20, isCompleted: true))
    }
}

#Preview {
    ProblemHistoryView()
}
