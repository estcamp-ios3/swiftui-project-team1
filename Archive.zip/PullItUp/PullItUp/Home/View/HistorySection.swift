//
//  HistorySection.swift
//  PullItUp
//
//  Created by catharina J on 7/7/25.
//
import SwiftUI
import SwiftData

struct HistorySection: View {
    @Environment(\.modelContext) private var modelContext

    @Query private var recentSessions: [ProblemSession]

    // @Query 초기화를 위한 init() 메서드
    init() {
        // FetchDescriptor를 생성하여 정렬 및 가져올 개수를 설정합니다.
        var descriptor = FetchDescriptor<ProblemSession>()
        
        // 정렬 기준을 명시적으로 ProblemSession의 프로퍼티에 대한 KeyPath로 지정합니다.
        descriptor.sortBy = [
            SortDescriptor(\ProblemSession.date, order: .reverse), // 날짜를 최신순으로
            SortDescriptor(\ProblemSession.quizType, order: .forward) // 같은 날짜일 경우 퀴즈 타입으로 정렬 (예: short -> long)
        ]
        
        // 가져올 ProblemSession 객체의 최대 개수를 3개로 제한합니다.
        descriptor.fetchLimit = 3
        
        // 설정된 FetchDescriptor를 사용하여 @Query를 초기화합니다.
        _recentSessions = Query(descriptor)
    }

    var body: some View {
        // NavigationLink로 카드 전체를 ProblemHistoryView로 연결합니다.
        NavigationLink(destination: ProblemHistoryView()) {
            VStack(alignment: .leading, spacing: 12) {
                headerView // "최근 이력" 제목과 아이콘 부분
                contentView // 이력 목록 또는 이력이 없을 때 메시지 부분
            }
            .padding()
            .frame(maxWidth: .infinity)
            .frame(height: 150) // 카드 높이 고정
            .background(Color.white) // 배경색
            .cornerRadius(15) // 모서리 둥글게
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5) // 그림자 효과
            .padding(.horizontal) // 좌우 여백
        }
    }

    // 카드 헤더 뷰 (제목과 아이콘)
    private var headerView: some View {
        HStack {
            Text("최근 이력")
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.black)
            Spacer()
            Image(systemName: "chart.bar.fill")
                .font(.title2)
                .foregroundColor(.blue)
        }
    }

    // 이력 유무에 따라 다른 내용을 표시하는 뷰
    private var contentView: some View {
        Group {
            if recentSessions.isEmpty {
                emptyHistoryView // 이력이 없을 때 표시될 뷰
            } else {
                filledHistoryView // 이력이 있을 때 표시될 뷰
            }
        }
    }

    // 이력이 없을 때 표시될 뷰
    private var emptyHistoryView: some View {
        VStack {
            Spacer() // 위아래로 공간을 채워 메시지를 가운데 정렬
            Text("아직 이력이 없어요.")
                .font(.subheadline)
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .center) // 텍스트를 중앙에 정렬
            Text("지금 바로 문제를 풀고 첫 이력을 만들어 보세요!")
                .font(.caption)
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .center) // 텍스트를 중앙에 정렬
            Spacer() // 위아래로 공간을 채워 메시지를 가운데 정렬
            
            HStack {
                Spacer()
                Text("문제 풀러가기") // 이력이 없을 때의 버튼 텍스트
                    .font(.footnote)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .background(Color.blue)
                    .cornerRadius(20)
            }
        }
    }

    // 이력이 있을 때 표시될 뷰
    private var filledHistoryView: some View {
        VStack(alignment: .leading, spacing: 5) {
            ForEach(recentSessions) { session in
                HStack {
                    // 날짜와 퀴즈 유형을 표시 (예: "2024.07.08 | 모의고사")
                    Text("\(formattedDate(session.date)) | \(sessionTypeDisplay(for: session.quizType))")
                        .font(.subheadline)
                        .foregroundColor(.black)
                    Spacer()
                    // 점수를 표시 (예: "10/10")
                    Text("\(session.scoreNumerator)/\(session.scoreDenominator)")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(session.isCompleted ? .blue : .red) // 세션 완료 여부에 따라 색상 다르게
                }
            }
            Spacer() // 이력 목록 아래 공간을 채움
            
            HStack {
                Spacer()
                Text("전체 이력 보러가기") // 이력이 있을 때의 버튼 텍스트
                    .font(.footnote)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 16)
                    .background(Color.blue)
                    .cornerRadius(20)
            }
        }
    }

    // Date 객체를 "yyyy.MM.dd" 형식의 문자열로 변환하는 헬퍼 함수
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy.MM.dd"
        return formatter.string(from: date)
    }

    // QuizType enum 값을 한글 문자열로 변환하는 헬퍼 함수
    private func sessionTypeDisplay(for type: QuizType) -> String {
        switch type {
        case .short: return "기출문제"
        case .long: return "모의고사"
        }
    }
}

// 프리뷰를 위한 코드 (ProblemSession 모델 컨테이너 필요)
#Preview {
    HistorySection()
        .modelContainer(for: ProblemSession.self, inMemory: true)
}
