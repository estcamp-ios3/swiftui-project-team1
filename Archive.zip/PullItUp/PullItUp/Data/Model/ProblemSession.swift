//
//  ProblemSession.swift
//  PullItUp
//
//  Created by suji chae on 7/8/25.
//

import Foundation
import SwiftData

@Model
final class ProblemSession: Identifiable {
    var id: UUID
    var date: Date
    var sessionNumber: Int
    var quizType: QuizType
    var scoreNumerator: Int
    var scoreDenominator: Int
    var isCompleted: Bool

    // 모든 저장 프로퍼티를 초기화하는 Designated Initializer (명시적 초기화)
    init(id: UUID = UUID(), // id에 기본값을 부여하고 init에서 명시적으로 초기화합니다.
         date: Date,
         sessionNumber: Int,
         quizType: QuizType,
         scoreNumerator: Int,
         scoreDenominator: Int,
         isCompleted: Bool = false) { // isCompleted는 기본값 유지
        
        self.id = id // id를 명시적으로 초기화
        self.date = date
        self.sessionNumber = sessionNumber
        self.quizType = quizType
        self.scoreNumerator = scoreNumerator
        self.scoreDenominator = scoreDenominator
        self.isCompleted = isCompleted
    }
}
